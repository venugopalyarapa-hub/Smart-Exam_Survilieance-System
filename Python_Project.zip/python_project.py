import cv2
from ultralytics import YOLO
import datetime
import os
import winsound  


model = YOLO("yolov8n.pt")


if not os.path.exists("suspicious_logs"):
    os.makedirs("suspicious_logs")


face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")


cap = cv2.VideoCapture(0)


def alert_sound():
    winsound.Beep(1000, 300)  


def log_event(frame, reason):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"suspicious_logs/{reason}_{timestamp}.jpg"
    cv2.imwrite(filename, frame)
    print(f"[ALERT] {reason} at {timestamp}")
    alert_sound()

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame_display = frame.copy()

    
    timestamp_text = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cv2.putText(frame_display, f"Time: {timestamp_text}", (10, 470),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray_frame, 1.1, 5)
    face_count = len(faces)

    if face_count == 0:
        cv2.putText(frame_display, "Face Not Detected!", (20, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        log_event(frame_display, "FaceNotDetected")
    elif face_count > 1:
        cv2.putText(frame_display, f"{face_count} Faces Detected!", (20, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        log_event(frame_display, "MultipleFacesDetected")

    for (x, y, w, h) in faces:
        cv2.rectangle(frame_display, (x, y), (x + w, y + h), (255, 0, 0), 2)

    results = model(frame)[0]
    for box in results.boxes:
        cls = int(box.cls[0])
        conf = box.conf[0]
        label = model.names[cls]

        if label == "cell phone" and conf > 0.5:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cv2.rectangle(frame_display, (x1, y1), (x2, y2), (0, 0, 255), 2)
            cv2.putText(frame_display, "Phone Detected!", (x1, y1 - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            log_event(frame_display, "PhoneDetected")

    cv2.imshow("Exam Monitor", frame_display)

    if cv2.waitKey(10) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
